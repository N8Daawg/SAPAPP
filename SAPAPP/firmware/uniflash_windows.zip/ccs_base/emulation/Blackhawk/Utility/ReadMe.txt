Blackhawk(tm) Utility Folder README

===================================
Blackhawk

123 Gaither Drive
Mount Laurel, New Jersey 08054-1701

Tel: +1 (856) 234-2629

http://www.blackhawk-dsp.com
===================================
2013 (c) EWA Technologies, Inc.


The following is a brief overview of the folders, their use, 
and the current version to be used if there is more than one 
option.



\BHProbe.2

Removed Octover 20123 for CCS v6 installation.
Contact Blackhawk for these utility files.



\BHDetect

Contains the latest version of our utility that scan your system 
to find inconsistancies with TI CCStudio files and our emulation 
driver files.


EOF